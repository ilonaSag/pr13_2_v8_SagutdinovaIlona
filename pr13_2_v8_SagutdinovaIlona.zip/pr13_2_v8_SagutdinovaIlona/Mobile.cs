﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr13_2_v8_SagutdinovaIlona
{
    class Mobile
    {
        private string name;
        private string surname;
        private int number;
        public Mobile(string name, string surname, int number)
        {
            this.name = name;
            this.surname = surname;
            this.number = number;
        }
        public string getName()
        {
            return this.name;
        }
        public string getSurname()
        {
            return this.surname;
        }
        public int getNumber()
        {
            return this.number;
        }
        public void setName(string name)
        {
            this.name = name;
        }
        public void setSurname(string surname)
        {
            this.surname = surname;
        }
        public void setNumber(int recordBookNumber)
        {
            this.number = recordBookNumber;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr13_2_v8_SagutdinovaIlona
{
    public partial class Form1 : Form
    {
        private DataGridViewColumn dataGridViewColumn1 = null;
        private DataGridViewColumn dataGridViewColumn2 = null;
        private DataGridViewColumn dataGridViewColumn3 = null;
        private HashSet<Mobile> mobileTable = new HashSet<Mobile>();
        public Form1()
        {
            InitializeComponent();
            initDataGridView();
        }
        private void initDataGridView()
        {
            dataGridView1.DataSource = null;
            dataGridView1.Columns.Add(getDataGridViewColumn1());
            dataGridView1.Columns.Add(getDataGridViewColumn2());
            dataGridView1.Columns.Add(getDataGridViewColumn3());
            dataGridView1.AutoResizeColumns();
        }
        private DataGridViewColumn getDataGridViewColumn1()
        {
            if (dataGridViewColumn1 == null)
            {
                dataGridViewColumn1 = new DataGridViewTextBoxColumn();
                dataGridViewColumn1.Name = "";
                dataGridViewColumn1.HeaderText = "Имя";
                dataGridViewColumn1.ValueType = typeof(string);
                dataGridViewColumn1.Width = dataGridView1.Width / 3;
            }
            return dataGridViewColumn1;
        }
        private DataGridViewColumn getDataGridViewColumn2()
        {
            if (dataGridViewColumn2 == null)
            {
                dataGridViewColumn2 = new DataGridViewTextBoxColumn();
                dataGridViewColumn2.Name = ""; ;
                dataGridViewColumn2.HeaderText = "Фамилия";
                dataGridViewColumn2.ValueType = typeof(string);
                dataGridViewColumn2.Width = dataGridView1.Width / 3;
            }
            return dataGridViewColumn2;
        }
        private DataGridViewColumn getDataGridViewColumn3()
        {
            if (dataGridViewColumn3 == null)
            {
                dataGridViewColumn3 = new DataGridViewTextBoxColumn();
                dataGridViewColumn3.Name = "";
                dataGridViewColumn3.HeaderText = "Номер";
                dataGridViewColumn3.ValueType = typeof(int);
                dataGridViewColumn3.Width = dataGridView1.Width / 3;
            }
            return dataGridViewColumn3;
        }
        private void showListInGrid()
        {
            dataGridView1.Rows.Clear();
            foreach (Mobile s in mobileTable)
            {
                DataGridViewRow row = new DataGridViewRow();
                DataGridViewTextBoxCell cell1 = new
                DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell2 = new
                DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell3 = new
                DataGridViewTextBoxCell();
                cell1.ValueType = typeof(string);
                cell1.Value = s.getName();
                cell2.ValueType = typeof(string);
                cell2.Value = s.getSurname();
                cell3.ValueType = typeof(int);
                cell3.Value = s.getNumber();
                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                dataGridView1.Rows.Add(row);
            }
        }
        private void addMobile (string name, string surname, int  number)
        {
            
            mobileTable.Add(new Mobile(name,surname,number));
            showListInGrid();
        }
        private void deleteMobile(int elementIndex)
        {
            if (elementIndex >= 0 && elementIndex < mobileTable.Count)
            {
                List<Mobile> tempList = mobileTable.ToList();
                tempList.RemoveAt(elementIndex);
                mobileTable.Clear();
                mobileTable.UnionWith(tempList);
                showListInGrid();
            }

        }
        private void editMobile(int index, string newName, string newSurname, int newRecordBookNumber)
        {
            List<Mobile> tempList = mobileTable.ToList();
            Mobile mobile = tempList[index];
            mobile.setName(newName);
            mobile.setSurname(newSurname);
            mobile.setNumber(newRecordBookNumber);
            showListInGrid();

        }
        private void Proverka(int index, int newNumber)
        {
            List<Mobile> tempList = mobileTable.ToList();
            if (index >= 0 && index < mobileTable.Count)
            {
                if (tempList.Any(s => s.getNumber() == newNumber && tempList.IndexOf(s) != index))
                {
                    tempList.RemoveAt(index);
                    MessageBox.Show("Такой номер телефона уже записан");
                    return;
                }
            }
            
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.SelectedCells[0].RowIndex;
            string name = textBox1.Text;
            string surname = textBox2.Text;
            int count = 0;
            bool num = true;
            string text = textBox3.Text;
            if (name == "" || surname == "" || textBox3.Text == "")
            {
                MessageBox.Show("Уберите пустые строки");
            }
            else
            {
                foreach (char c in textBox3.Text)
                {
                    count++;
                }
                foreach (char c in textBox3.Text)
                {
                    if (!char.IsDigit(c) || count < 9 || count > 9)
                    {
                        num = false;
                        break;
                    }
                }
                if (num)
                {
                    int number = int.Parse(textBox3.Text);
                    Proverka(index, number);
                    addMobile(name, surname, number);
                }
                else
                    MessageBox.Show("Введите число или номер у которого длина 9");
            }
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int selectedRow = dataGridView1.SelectedCells[0].RowIndex;
            DialogResult dr = MessageBox.Show("Удалить номер?", "", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    deleteMobile(selectedRow);
                }
                catch (Exception)
                {
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int selectedRow = dataGridView1.SelectedCells[0].RowIndex;
                string newName = textBox1.Text;
                string newSurname = textBox2.Text;
                int newRecordBookNumber = int.Parse(textBox3.Text);
                editMobile(selectedRow, newName, newSurname, newRecordBookNumber);

            }
        }
    }
}

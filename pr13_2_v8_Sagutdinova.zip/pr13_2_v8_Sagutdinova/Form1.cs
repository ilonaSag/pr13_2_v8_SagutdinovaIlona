﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr13_2_v8_Sagutdinova
{

    public partial class Form1 : Form
    {
        private DataGridViewColumn dataGridViewColumn1 = null;
        private DataGridViewColumn dataGridViewColumn2 = null;
        private DataGridViewColumn dataGridViewColumn3 = null;
        private IList<Student> studentList = new List<Student>();
        public Form1()
        {
            InitializeComponent();
            initDataGridView();
        }
        private void initDataGridView()
        {
            dataGridView1.DataSource = null;
            dataGridView1.Columns.Add(getDataGridViewColumn1());
            dataGridView1.Columns.Add(getDataGridViewColumn2());
            dataGridView1.Columns.Add(getDataGridViewColumn3());
            dataGridView1.AutoResizeColumns();
        }
        private DataGridViewColumn getDataGridViewColumn1()
        {
            if (dataGridViewColumn1 == null)
            {
                dataGridViewColumn1 = new DataGridViewTextBoxColumn();
                dataGridViewColumn1.Name = "";
                dataGridViewColumn1.HeaderText = "Имя";
                dataGridViewColumn1.ValueType = typeof(string);
                dataGridViewColumn1.Width = dataGridView1.Width / 3;
            }
            return dataGridViewColumn1;
        }
        private DataGridViewColumn getDataGridViewColumn2()
        {
            if (dataGridViewColumn2 == null)
            {
                dataGridViewColumn2 = new DataGridViewTextBoxColumn();
                dataGridViewColumn2.Name = ""; ;
                dataGridViewColumn2.HeaderText = "Фамилия";
                dataGridViewColumn2.ValueType = typeof(string);
                dataGridViewColumn2.Width = dataGridView1.Width / 3;
            }
            return dataGridViewColumn2;
        }
        private DataGridViewColumn getDataGridViewColumn3()
        {
            if (dataGridViewColumn3 == null)
            {
                dataGridViewColumn3 = new DataGridViewTextBoxColumn();
                dataGridViewColumn3.Name = "";
                dataGridViewColumn3.HeaderText = "Зачетка";
                dataGridViewColumn3.ValueType = typeof(string);
                dataGridViewColumn3.Width = dataGridView1.Width / 3;
            }
            return dataGridViewColumn3;
        }
        private void addStudent(string name, string surname, string
        recordBookNumber)
        {

            studentList.Add(new Student(name, surname, recordBookNumber));
            
            showListInGrid();
        }
        private void deleteStudent(int elementIndex)
        {
            if (elementIndex >= 0 && elementIndex < studentList.Count)
            {
                studentList.RemoveAt(elementIndex);
                showListInGrid();
            }
            
        }
        private void showListInGrid()
        {
            dataGridView1.Rows.Clear();
            foreach (Student s in studentList)
            {
                DataGridViewRow row = new DataGridViewRow();
                DataGridViewTextBoxCell cell1 = new
                DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell2 = new
                DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell3 = new
                DataGridViewTextBoxCell();
                cell1.ValueType = typeof(string);
                cell1.Value = s.getName();
                cell2.ValueType = typeof(string);
                cell2.Value = s.getSurname();
                cell3.ValueType = typeof(string);
                cell3.Value = s.getRecordBookNumber();
                row.Cells.Add(cell1);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                dataGridView1.Rows.Add(row);
            }
        }


        private void editStudent(int index, string newName, string newSurname, string newRecordBookNumber)
        {
                Student student = studentList[index];
                student.setName(newName);
                student.setSurname(newSurname);
                student.setRecordBookNumber(newRecordBookNumber);
                showListInGrid();
            
        }
        private void Proverka(int index, string newRecordBookNumber)
        {
            if (index >= 0 && index < studentList.Count)
            {
                if (studentList.Any(s => s.getRecordBookNumber() == newRecordBookNumber && studentList.IndexOf(s) != index))
                {
                    studentList.RemoveAt(index);
                    MessageBox.Show("Студент с таким номером зачетки уже существует!");
                    return;
                }
            }
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            int index = dataGridView1.SelectedCells[0].RowIndex;
            string name = textBox1.Text;
            string surname = textBox2.Text;
            string recordBookNumber = textBox3.Text;
            Proverka(index, recordBookNumber);
            addStudent(name, surname, recordBookNumber);
        }

        private void удалитьToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            int selectedRow = dataGridView1.SelectedCells[0].RowIndex;
            DialogResult dr = MessageBox.Show("Удалить студента?", "", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    deleteStudent(selectedRow);
                }
                catch (Exception)
                {
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int selectedRow = dataGridView1.SelectedCells[0].RowIndex;
                string newName = textBox1.Text;
                string newSurname = textBox2.Text;
                string newRecordBookNumber = textBox3.Text;
                editStudent(selectedRow, newName, newSurname, newRecordBookNumber);

            }
        }
    }
}

       

